package com.sinta.project2katalogfilm;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class FilmAdapter extends RecyclerView.Adapter<FilmAdapter.ViewHolder> {
    private Context context;
    private ArrayList<Film> FilmList = new ArrayList<>();
    private static final String TAG = "Tagnya aja";

    public FilmAdapter(Context context) {
        this.context = context;
    }

    public ArrayList<Film> getListMovie() {
        return FilmList;
    }

    public void setListMovie(ArrayList<Film> listFilm) {
        this.FilmList = listFilm;
        }
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemRow = LayoutInflater.from(parent.getContext()).inflate(R.layout.template_movie, parent, false);
        return new ViewHolder(itemRow);
    }

    @Override
    public void onBindViewHolder (ViewHolder holder, final int position) {
        Glide.with(context).load(FilmList.get(position).getThumbnailPath())
                .apply(new RequestOptions()
                .override(72, 48))
                .into(holder.photo);
        holder.title.setText(FilmList.get(position).getTitle());
        holder.releaseDate.setText(FilmList.get(position).getRelease_date());
        holder.voteAverage.setText(FilmList.get(position).getVote_average());
        holder.linear_layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Film film1 = getListMovie().get(position);
                Intent i = new Intent(context, DetailActivity.class);
                i.putExtra("photo", film1.getThumbnailPath());
                i.putExtra("title", film1.getTitle());
                i.putExtra("overview", film1.getOverview());
                i.putExtra("voteAverage", film1.getVote_average());
                i.putExtra("releasedate", film1.getRelease_date());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        Log.d(TAG, "getItemCount: " + FilmList.size());
        return FilmList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView photo;
        TextView title, releaseDate,voteAverage;
        LinearLayout linear_layout;
        public ViewHolder(View itemView) {
            super(itemView);
            photo = itemView.findViewById(R.id.film_photo);
            title = itemView.findViewById(R.id.film_title);
            releaseDate = itemView.findViewById(R.id.film_tanggal);
            voteAverage = itemView.findViewById(R.id.rating);
            linear_layout = itemView.findViewById(R.id.linear_film);
        }
    }
}
