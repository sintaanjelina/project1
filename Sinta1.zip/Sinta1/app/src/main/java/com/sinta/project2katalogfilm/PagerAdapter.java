package com.sinta.project2katalogfilm;

import android.content.Context;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;

/**
 * Menyediakan {@link Fragment}untuk view pager.
 */
public class PagerAdapter extends android.support.v4.app.FragmentPagerAdapter {
    private Context context;
    String[] tabTitles;

    public PagerAdapter(FragmentManager fm, Context context) {
        super(fm);
        tabTitles = new String[]{context.getResources().getString(R.string.now_playing), context.getResources().getString(R.string.uo_coming), context.getResources().getString(R.string.search)};

    }

    @Override

    public Fragment getItem(int position) {
        if (position == 0) {
            return new NowPlayingFragment();
        } else if (position == 1) {
            return new UpcomingFragment();
        } else {
            return new SearchFragment();
        }
    }

    @Override
    public int getCount() {
        return 3;
    }


     @Override
     public CharSequence getPageTitle(int position) {
    return tabTitles[position];
       }
}
