package com.sinta.project2katalogfilm;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import android.support.v4.content.Loader;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SearchView;

import java.util.ArrayList;

public class SearchFragment extends Fragment implements LoaderCallbacks<ArrayList<Film>> {
    private static final String TAG = "TAGNYA";
    FilmAdapter adapter;
    SearchView searching;
    RecyclerView recyclerViewList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_search, container, false);
        searching = root.findViewById(R.id.edt_search);
        searching.setOnQueryTextListener(myListener);
        recyclerViewList = root.findViewById(R.id.rv_list);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getActivity());
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);

        adapter = new FilmAdapter(getActivity());
        recyclerViewList.setLayoutManager(linearLayoutManager);
        adapter.notifyDataSetChanged();
        recyclerViewList.setAdapter(adapter);
        return root;

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle bundle = new Bundle();
        getLoaderManager().initLoader(2, bundle, this);

    }

    @Override
    public Loader<ArrayList<Film>> onCreateLoader(int id, Bundle args) {
        String namaFilm = null;
        if (args != null) {
            namaFilm = args.getString(EXTRAS_SEARCH);
        }
        return new QueryLoader(getContext(), namaFilm);
    }

    @Override
    public void onLoadFinished(Loader<ArrayList<Film>> loader, ArrayList<Film> data) {

        adapter.setListMovie(data);
        adapter.notifyDataSetChanged();
        Log.d(TAG, "onLoadFinished: " + data.size());

    }

    @Override
    public void onLoaderReset(Loader<ArrayList<Film>> loader) {
        adapter.setListMovie(null);
    }

    private String EXTRAS_SEARCH = "Cari di sini";
    SearchView.OnQueryTextListener myListener = new SearchView.OnQueryTextListener() {
        @Override
        public boolean onQueryTextSubmit(String query) {
            String pencarian = searching.getQuery().toString();
            String fixPencarian = null;

            fixPencarian = pencarian.replace(" ", "%20");

            if (TextUtils.isEmpty(pencarian)) return false;

            Bundle bundle = new Bundle();
            bundle.putString(EXTRAS_SEARCH, fixPencarian);
            getLoaderManager().restartLoader(2, bundle, SearchFragment.this);
            return true;
        }

        @Override
        public boolean onQueryTextChange(String newText) {
            return false;
        }


    };

}
