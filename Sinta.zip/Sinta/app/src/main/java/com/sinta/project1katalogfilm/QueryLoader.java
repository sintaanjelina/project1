package com.sinta.project1katalogfilm;

import android.content.AsyncTaskLoader;
import android.content.Context;
import android.util.Log;

import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.SyncHttpClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

import cz.msebera.android.httpclient.Header;

public class QueryLoader extends AsyncTaskLoader<ArrayList<Film>> {
    private static final String TAG = "Tagnya";
    private boolean mHasResult = false;
    private ArrayList<Film> Data;
    private String namaFilm;

    public QueryLoader(Context context, String namaFilm) {
        super(context);
        onContentChanged();
        this.namaFilm = namaFilm;
    }
    @Override
    protected void onStartLoading() {
        if (takeContentChanged())
            forceLoad();
        else if (mHasResult)
            deliverResult(Data);
    }

    @Override
    public void deliverResult(final ArrayList<Film> data) {
        this.Data = data;
        mHasResult = true;
        super.deliverResult(data);
    }

    @Override
    protected void onReset() {
        super.onReset();
        onStopLoading();
        if (mHasResult) {
            onReleaseResouces(Data);
            Data = null;
            mHasResult = false;
        }
    }

    private final String API_KEY = "5066125f31d45991a214fb07b677754b";
    @Override
    public ArrayList<Film> loadInBackground() {
        String url = "https://api.themoviedb.org/3/search/movie?api_key=" + API_KEY + "&language=en-US&query=" + namaFilm.replace(" ", "%20");
        Log.d(TAG, "LoadInBackground: "+url);
        SyncHttpClient sync = new SyncHttpClient();
        final ArrayList<Film> arrayList = new ArrayList<>();
         sync.get(url, new AsyncHttpResponseHandler() {
            @Override
            public void onStart() {
                super.onStart();
                setUseSynchronousMode(true);
            }
             @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                Log.d(TAG, "onSuccess executed");
                try {     String result = new String(responseBody);
                        JSONObject jsonObject = new JSONObject(result);
                  JSONArray jsonArray = jsonObject.getJSONArray("results");
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject film1 = jsonArray.getJSONObject(i);
                        Film film = new Film(film1);
                        arrayList.add(film);
                        Log.d(TAG, "Data ke- "+ i+ " " +jsonArray.getJSONObject
                                (i).getString("title")+" "
                                +jsonArray.getJSONObject(i).getString("overview")+ " " +jsonArray.getJSONObject(i).getString("release_date")
                                +" "+jsonArray.getJSONObject(i).getString("poster_path"));
                }
                } catch (Exception e)
              {
                  Log.d(TAG, "Failed 404");
                  e.printStackTrace();
              }
         }
             @Override
             public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                 Log.d(TAG, "Oh no, Failed. onFailure executed"); }

         });
    return arrayList;
    }

    protected void onReleaseResouces (ArrayList<Film> data) {
    }
}


