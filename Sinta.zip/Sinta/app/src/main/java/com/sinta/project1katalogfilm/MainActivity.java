package com.sinta.project1katalogfilm;

import android.app.LoaderManager;
import android.content.Loader;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<ArrayList<Film>> {
    EditText cari;
    Button btn_cari;
    ArrayList<Film> film;
    public RecyclerView mRecyclerView;
    FilmAdapter filmAdapter;
    private static final String TAG = "Ini tag nya";
    private String EXTRAS_SEARCH = "pencarian";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mRecyclerView = findViewById(R.id.category_film);
        btn_cari = findViewById(R.id.btn_cari);
        cari = findViewById(R.id.txt_cari);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(this);
        // use a linear layout manager
        filmAdapter = new FilmAdapter(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setAdapter(filmAdapter);
        btn_cari.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pencarian = cari.getText().toString();

                if (TextUtils.isEmpty(pencarian)) return;

                Bundle bundle = new Bundle();
                bundle.putString(EXTRAS_SEARCH, pencarian);
                getLoaderManager().restartLoader(0, bundle, MainActivity.this);
            }
        });
    }

    @Override
    public Loader<ArrayList<Film>> onCreateLoader(int id, Bundle args) {
        String NamaFilm = "";
        if (args != null) {
            NamaFilm = args.getString(EXTRAS_SEARCH);
        }
        return new QueryLoader(this, NamaFilm);
    }

    @Override
    public void onLoadFinished(Loader<ArrayList<Film>> loader, ArrayList<Film> data) {
        filmAdapter.setListMovie(data);
        filmAdapter.notifyDataSetChanged();
        Log.d(TAG, "onLoadFinished start");
    }

    @Override
    public void onLoaderReset(Loader<ArrayList<Film>> loader) {
        filmAdapter.setListMovie(null);
        Log.d(TAG, "onLoaderReset start");
    }
}
