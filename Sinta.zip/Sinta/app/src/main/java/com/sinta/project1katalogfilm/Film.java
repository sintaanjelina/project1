package com.sinta.project1katalogfilm;

import org.json.JSONObject;

public class Film{
    private String thumbnailPath;
    String title;
    String overview;
    String release_date;
    String vote_average;
    public Film (JSONObject jsonObject) {
        try {
            String title = jsonObject.getString("title");
            String overview = jsonObject.getString("overview");
            String releaseDate = jsonObject.getString("release_date");
            String poster_path = jsonObject.getString("poster_path");
            String voteAverage = jsonObject.getString("vote_average");

            this.thumbnailPath =poster_path;
            this.title = title;
            this.overview = overview;
            this.vote_average = voteAverage;
            this.release_date = releaseDate;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void setThumbnailPath(String thumbnailPath) {
        this.thumbnailPath = thumbnailPath;
    }
    public String getThumbnailPath() {
        String link = "http://image.tmdb.org/t/p/w300/";
        return link + thumbnailPath;
    }


    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }
    public String getRelease_date() {
        return release_date;
    }

    public void setRelease_date(String release_date) {
        this.release_date = release_date;
    }

    public String getVote_average(){return vote_average;}
    public void setVote_average(String vote_average){this.vote_average = vote_average;}
}
