package com.sinta.project1katalogfilm;

import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DetailActivity extends AppCompatActivity {
ImageView imgPhoto;
TextView judul1, filmtanggal, deskripsi, rating1;
    String judul, imagephoto, tanggal_film, overview, rating;
    private Context context1;
    private String TAG = "ini tagnya";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        imgPhoto = (ImageView) findViewById(R.id.foto_film);
        judul1 = (TextView) findViewById(R.id.judul_film);
        filmtanggal = (TextView) findViewById(R.id.film_tanggal);
        deskripsi = (TextView) findViewById(R.id.film_deskripsi);
        rating1 = (TextView) findViewById(R.id.rating);
        judul = getIntent().getExtras().getString("title");
        imagephoto = getIntent().getExtras().getString("photo");
        tanggal_film = getIntent().getExtras().getString("releasedate");
        overview = getIntent().getExtras().getString("overview");
        rating = getIntent().getExtras().getString("voteAverage");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd");
        try {
            Date date = dateFormat.parse(tanggal_film);
            SimpleDateFormat formati = new SimpleDateFormat("EEEE, MMM d, yyyy");
            String date_release = formati.format(date);
            filmtanggal.setText(date_release);
        } catch (Exception e) {
            e.printStackTrace();
        }
        Log.d(TAG,"DetailActivity " + judul+ " "+ imagephoto + " "+ overview);
        Glide.with(this)
                .load(imagephoto).apply(new RequestOptions().override(320, 160))
                .into(imgPhoto);
        judul1.setText(judul);
        rating1.setText(rating);
        deskripsi.setText(overview);
    }
}
